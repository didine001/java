/**
 * A flexible implementation of rendering on a SWT Canvas component that supports
 * passive rendering. Active rendering is not possible in SWT.
 */
package org.jdesktop.swt.animation.rendering;