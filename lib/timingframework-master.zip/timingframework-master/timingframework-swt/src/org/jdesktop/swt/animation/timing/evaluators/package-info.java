/**
 * Evaluator implementations for the several useful SWT types.
 */
package org.jdesktop.swt.animation.timing.evaluators;