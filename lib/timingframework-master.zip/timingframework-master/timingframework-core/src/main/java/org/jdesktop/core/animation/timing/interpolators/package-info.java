/**
 * Several useful interpolator implementations for animations.
 */
package org.jdesktop.core.animation.timing.interpolators;