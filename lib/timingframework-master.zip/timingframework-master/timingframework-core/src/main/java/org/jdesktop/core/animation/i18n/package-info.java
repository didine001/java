/**
 * Provides internationalized messages, in particular error messages, to
 * the Timing Framework.
 */
package org.jdesktop.core.animation.i18n;